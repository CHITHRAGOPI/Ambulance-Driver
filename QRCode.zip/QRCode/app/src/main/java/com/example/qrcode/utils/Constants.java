package com.example.qrcode.utils;

/**
 * Created by MyPc on 09-09-2017.
 */

public class Constants {

    public static final String SHARED_PREF = "location_tracking";
    public static final String IP="ipaddress";
    public static final String USERNAME="username";
    public static final String PASSWORD="password";
    public static final String CONDUCTO_ID="conductor_id";
    public static final String STATION_ID="station_id";
    public static final String BUS_ID="bus_id";
    public static final String BUS_NO="bus_no";
    public static  final String IMEI="imei";
    public static final String LOGIN_CHECK="login_check";



}
