package com.example.qrcode;


import com.example.qrcode.model.login.LoginBase;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface ApiInterface {

    @GET("login.php")
    Call<LoginBase> userLogin(@Query("email") String username, @Query("password") String password);




}


