package com.example.qrcode;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.qrcode.model.login.LoginBase;
import com.example.qrcode.model.login.LoginItem;
import com.example.qrcode.utils.GlobalPreference;
import com.google.gson.Gson;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {

    @BindView(R.id.edt_login_username)
    EditText mUsernameLoginEdit;
    @BindView(R.id.edt_login_password)
    EditText mPasswordLoginEdit;


    private ApiInterface mApiInterface;
    private GlobalPreference mGlobalPreference;
    private Gson gson;
    private static final String TAG = "LoginActivity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        ButterKnife.bind(this);
        init();
    }


    private void init() {
        mGlobalPreference = new GlobalPreference(this);
        gson = new Gson();
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

    }

    @OnClick(R.id.btn_login_submit)
    public void login() {

        String username = mUsernameLoginEdit.getText().toString();
        String password = mPasswordLoginEdit.getText().toString();
  
        if (!TextUtils.isEmpty(username) || !TextUtils.isEmpty(password)) {
            mApiInterface = ApiClient.getRetrofit(mGlobalPreference.RetrieveIp()).create(ApiInterface.class);

            Call<LoginBase> loginBaseCall = mApiInterface.userLogin(username, password);
            loginBaseCall.enqueue(new Callback<LoginBase>() {
                @Override
                public void onResponse(Call<LoginBase> call, Response<LoginBase> response) {
                    Log.d(TAG, "onResponse: " + response.body().isSuccess());
                    if(response.body().isSuccess()){
                        startActivity(new Intent(LoginActivity.this, HomeActivity.class));

                    }else{

                        Toast.makeText(LoginActivity.this, "Login Error!Invalid username or password", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onFailure(Call<LoginBase> call, Throwable t) {
                    
                    Log.d(TAG, "onFailure: " + t);
                }
            });

        } else {

            Toast.makeText(this, R.string.login_empty_fields, Toast.LENGTH_SHORT).show();
        }

    }
    
}
