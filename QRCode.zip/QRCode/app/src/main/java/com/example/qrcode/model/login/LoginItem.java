package com.example.qrcode.model.login;


import com.google.gson.annotations.SerializedName;


public class LoginItem {

	@SerializedName("password")
	private String password;

	@SerializedName("mail_id")
	private String mailId;

	@SerializedName("name")
	private String name;

	@SerializedName("mobile")
	private String mobile;

	@SerializedName("id")
	private String id;

	public void setPassword(String password){
		this.password = password;
	}

	public String getPassword(){
		return password;
	}

	public void setMailId(String mailId){
		this.mailId = mailId;
	}

	public String getMailId(){
		return mailId;
	}

	public void setName(String name){
		this.name = name;
	}

	public String getName(){
		return name;
	}

	public void setMobile(String mobile){
		this.mobile = mobile;
	}

	public String getMobile(){
		return mobile;
	}

	public void setId(String id){
		this.id = id;
	}

	public String getId(){
		return id;
	}

	@Override
 	public String toString(){
		return 
			"LoginItem{" +
			"password = '" + password + '\'' + 
			",mail_id = '" + mailId + '\'' + 
			",name = '" + name + '\'' + 
			",mobile = '" + mobile + '\'' + 
			",id = '" + id + '\'' + 
			"}";
		}
}