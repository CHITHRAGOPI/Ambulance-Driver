package com.example.qrcode.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class GlobalPreference {

    private SharedPreferences mSharedPreferences;
    private Context mContext;
    private SharedPreferences.Editor mEditor;

    public GlobalPreference(Context mContext) {
        this.mContext = mContext;
        mSharedPreferences = mContext.getSharedPreferences(Constants.SHARED_PREF, Context.MODE_PRIVATE);
        mEditor = mSharedPreferences.edit();
    }

    public void addIp(String ip) {
        mEditor.putString(Constants.IP, ip);
        mEditor.apply();
    }

    public void saveCredentials(String username, String password, String conductor_id,String station_id) {
        mEditor.putString(Constants.USERNAME,username);
        mEditor.putString(Constants.PASSWORD, password);
        mEditor.putString(Constants.CONDUCTO_ID, conductor_id);
        mEditor.putString(Constants.STATION_ID,station_id);
        mEditor.apply();
    }


    public void saveBusDetails(String busId,String busNo,String imei){
        mEditor.putString(Constants.BUS_ID,busId);
        mEditor.putString(Constants.BUS_NO,busNo);
        mEditor.putString(Constants.IMEI,imei);
        mEditor.apply();
    }

    public void setLoginStatus(Boolean value){
        mEditor.putBoolean(Constants.LOGIN_CHECK,value);
        mEditor.apply();
    }
    public boolean getLoginStatus(){
     return  mSharedPreferences.getBoolean(Constants.LOGIN_CHECK,false);
    }

    public String getStationId(){
        return  mSharedPreferences.getString(Constants.STATION_ID,"");
    }
    public String getPassword() {
        return mSharedPreferences.getString(Constants.PASSWORD, "");
    }

    public  String getUsername(){
        return mSharedPreferences.getString(Constants.USERNAME,"");
    }

    public String getConductorId(){
        return mSharedPreferences.getString(Constants.CONDUCTO_ID,"");
    }

    public String getBusId(){
        return mSharedPreferences.getString(Constants.BUS_ID,"");
    }
    public String getBusNo(){
        return mSharedPreferences.getString(Constants.BUS_NO,"");
    }
    public String getImei(){
        return mSharedPreferences.getString(Constants.IMEI,"");
    }

    public String RetrieveIp() {
        return mSharedPreferences.getString(Constants.IP, "");
    }

}
